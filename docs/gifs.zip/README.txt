Percent-General-9B — Six selected recorded decisions
Five selected successes vs Jev 1.13.0, plus a chess win vs StartLux-Decision-v1-27B.
Selection from exploratory runs; not an overall win rate or general superiority claim.
Models choose candidate actions from structured states. Shopping and support are simulations.
Source outcomes: chess 1W/15L/36D; tic-tac-toe 1W/1L; Connect Four 1W/1L;
Othello 1W/3L; shopping 2W/1T; support 1W/11T.
Moves, workflow states and candidate values are retained from saved records.
Rule-only steps and the preset chess opening are not model choices.
Checks were performed by this project, not an external certifier.
The chess GIF shows the final 12 half-moves; other GIFs show the complete selected records.
Workflow progress compares action indices, not response times.
Chess piece artwork: Colin M. L. Burnett (Cburnett), BSD 3-Clause option.
Full terms are included in Cburnett-BSD-3-Clause.txt; details in NOTICE.txt.
Chess retains the original rich input protocol. Another game in the source run exposed an incorrect immediate-capture description, and upstream notation reduces mate # to check +. Both models share the input-construction rules and complete legal candidates. Legal move replay confirms this game's checkmate, not the accuracy of every input description. The corrected capture-description protocol has only CPU checks and has not been retested in GPU matches. This is a recorded example, not a standard chess-strength ranking.
